package com.wjcx.astar.appliance;


import com.wjcx.astar.mapcreater.MapGenerator;

public class AStarApp {
	public static void main(String[] args) {
		new MapGenerator();
		
	}

}
