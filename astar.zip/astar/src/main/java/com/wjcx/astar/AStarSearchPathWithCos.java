package com.wjcx.astar;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.wjcx.astar.model.MapInit;
import com.wjcx.astar.model.Node;
import com.wjcx.astar.model.Position;
import com.wjcx.astar.model.Vector;


public class AStarSearchPathWithCos implements AStar{
	public final static int ROAD_BAR=0;
	public final static char ROAD=5;
	public final static int ROAD_COST=10;
	public final static int DIRECTCONTS=ROAD_COST;
	//public final static int OBSCONTS=DIRECTCONTS-1;
	List<Node> openTable=null;
	List<Node> closeTable=null;
	private long start=0L;
	private long end=0L;
	private int search_nodes=0;
	private int road_nodes=0;
	private int total_nodes=0;
	public void pathSearching(MapInit map){
		if(map==null)
			return ;
		
		start=System.nanoTime();
		
		openTable=new ArrayList<Node>();
		closeTable=new ArrayList<Node>();
		long s1=System.nanoTime();
		float sH=cal_H(map.getStart().getPosition(), map.getGoal().getPosition(), map.getStart().getPosition(),null);
		System.out.println(System.nanoTime()-s1);
		System.out.println(sH);
		map.getStart().setH(sH);
		map.getStart().cal_F();
		map.getGoal().setG((int)sH);
		map.getGoal().cal_F();
		openTable.add(map.getStart());
		stepMoving(map);
		
		end=System.nanoTime();
		
		if(openTable.size()>0){
			total_nodes+=openTable.size();
		}
		if(closeTable.size()>0){
			total_nodes+=closeTable.size();
			search_nodes+=closeTable.size();
		}
		
	}

	public void stepMoving(MapInit map) {
		// TODO Auto-generated method stub
		while(openTable.size()>0){
			if(isInCloseTable(map.getGoal())){
				move(map.getMaps(),map.getGoal());
				break;
			}
			Node current=extractMin(openTable);
			openTable.remove(current);
			closeTable.add(current);
			addNeighborsToOpenTable(map,current);
			
		}
		
	}
	
	private Node extractMin(List<Node> open){
		Node min=null;
		if(open.size()==0){
			return null;
		}else{
			min=open.get(0);
			Iterator<Node> iterator=open.iterator();
			while(iterator.hasNext()){
				Node current=iterator.next();
				if(((int)(min.getF()*10000))>((int)(current.getF()*10000))){
					min=current;
				}
			}
			return min;
		
		}
	}
	
	public boolean isInCloseTable(Node goal) {
		
		Node node=search(goal,closeTable);
		if(node==null){
			return false;
		}else {
			return true;
		}
	}
	
	public Node search(Node node,List<Node> list){
		//Node newNode=null;
		if(node==null||list==null){
			return null;
		}
		Iterator<Node> iterator=list.iterator();
		while(iterator.hasNext()){
			Node n=iterator.next();
			if(node.equals(n)){
				return n;
			}
		}
		return null;
	}
	
	public boolean isInCloseTable(int x,int y) {
		
		if(search(new Position(x,y),closeTable)!=null){
			return true;
		}
		return false;
	}
	
	public Node search(Position position,List<Node> list){
		if(position==null||list==null){
			return null;
		}
		Iterator<Node> iterator=list.iterator();
		while(iterator.hasNext()){
			Node n=iterator.next();
			if(position.equals(n.getPosition())){
				return n;
			}
		}
		return null;
	}
	
	public void addNeighborsToOpenTable(MapInit map, Node current) {
		// TODO Auto-generated method stub
		int x=current.getPosition().getX();
		int y=current.getPosition().getY();
		addNeighborsToOpenProcess(map,current,x,y-1,ROAD_COST);
		addNeighborsToOpenProcess(map,current,x+1,y,ROAD_COST);
		addNeighborsToOpenProcess(map,current,x,y+1,ROAD_COST);
		addNeighborsToOpenProcess(map,current,x-1,y,ROAD_COST);
		
	}

	public void addNeighborsToOpenProcess(MapInit map, Node current, int x, int y, int roadCost) {
		// TODO Auto-generated method stub
		if(canNodeReach(map,x,y)&&!isInCloseTable(x,y)){
			//System.out.println(x+","+y+" canReach && not in CloseTable");
			Node start=map.getStart();
			Node end=map.getGoal();
			Position position=new Position(x,y);
			/*
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
			int g=current.getG()+roadCost;
			Node child=searchInOpenTable(position);
			
			if(child==null){
				float h=cal_H(start.getPosition(),end.getPosition(),position,null);
				if(isEndNode(end.getPosition(),position)){
					child=end;
					child.setPrefix(current);
					child.setG(g);
					child.setH(h);
					child.cal_F();
				}else{
					child=new Node(g,h,current,position);
					child.cal_F();
				}
				openTable.add(child);
				
			}else if(child.getG()>g){
				child.setG(g);
				child.setPrefix(current);
				child.cal_F();
				//openTable.update(child, index);
				
			}
		}
	}

	public boolean canNodeReach(MapInit map, int x, int y) {
		// TODO Auto-generated method stub
		if(x<0||x>=map.getWidth()||y<0||y>=map.getHeight()){
			return false;
		}else if(map.getMaps()[x][y]!=ROAD_BAR){
			return true;
		}
		return false;
	}

	public boolean isEndNode(Position end, Position position) {
		// TODO Auto-generated method stub
		return position!=null&&end.equals(position);
	}

	public float cal_H(Position start,Position goal, Position current,int[][] map) {
		// TODO Auto-generated method stub
		
		float direction_cost=threaten_tri(start,goal,current);
		int distance_cost=Math.abs(goal.getX()-current.getX())+Math.abs(goal.getY()-current.getY());
		
		return distance_cost+direction_cost;
	}

	public float threaten_tri(Position start, Position goal, Position current) {
		// TODO Auto-generated method stub
		Vector v1=makeVector(start,goal);
		Vector v2=makeVector(start,current);
		int multiply=Vector.vectorMultiply(v1, v2);
		double v1Norm=v1.vectorNorm();
		double v2Norm=v2.vectorNorm();
		//System.out.println((1-(multiply/(v1Norm*v2Norm)))*DIRECTCONTS);
		float cost=(float)((1-(multiply/(v1Norm*v2Norm)))*DIRECTCONTS);
		//System.out.println(cost);
		return cost;
	}
	
	public Vector makeVector(Position start, Position current) {
		// TODO Auto-generated method stub
		int vx=current.getX()-start.getX();
		int vy=current.getY()-start.getY();
		return new Vector(vx,vy);
	}
	
	public Node searchInOpenTable(Position position) {
		// TODO Auto-generated method stub
		
	
		if(position==null||openTable.isEmpty()){
			return null;
		}
		for(int i=0;i<openTable.size();i++){
			Node node=openTable.get(i);
			
			if(node.getPosition().equals(position)){
				
				return node;
			}
			
		}
		return null;
	}

	public void move(int[][] maps, Node end) {
		// TODO Auto-generated method stub
		if(end==null||maps==null){
			return;
		}
		end=end.getPrefix();
		while(end!=null&&end.getPrefix()!=null){
			Position position=end.getPosition();
			maps[position.getX()][position.getY()]=ROAD;
			end=end.getPrefix();
			road_nodes++;
		}
	}

	public long getStart() {
		return start;
	}

	public void setStart(long start) {
		this.start = start;
	}

	public long getEnd() {
		return end;
	}

	public void setEnd(long end) {
		this.end = end;
	}

	public int getSearch_nodes() {
		return search_nodes;
	}

	public void setSearch_nodes(int search_nodes) {
		this.search_nodes = search_nodes;
	}

	public int getRoad_nodes() {
		return road_nodes;
	}

	public void setRoad_nodes(int road_nodes) {
		this.road_nodes = road_nodes;
	}

	public int getTotal_nodes() {
		return total_nodes;
	}

	public void setTotal_nodes(int total_nodes) {
		this.total_nodes = total_nodes;
	}
	
	
	
}
