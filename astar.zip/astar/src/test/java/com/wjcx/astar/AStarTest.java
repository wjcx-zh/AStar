package com.wjcx.astar;

import static org.junit.Assert.*;

import org.junit.Test;

public class AStarTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
